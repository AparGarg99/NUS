from flask import Flask, Response, request
import json
from flask import Flask, request, make_response, jsonify
import requests

app = Flask(__name__)
APIKEY = "0b989751a1cf323b4ca2e6a07163ea82"

def getjson(url):
    resp =requests.get(url)
    return resp.json()

def getWeatherInfo(location):
    API_ENDPOINT = f"http://api.openweathermap.org/data/2.5/weather?APPID={APIKEY}&q={location}"
    data = getjson(API_ENDPOINT)
    data = data['weather'][0]['main']

    if(data=='Clouds'):
        result = 'Cloudy'
    elif(data=='Mist'):
        result = 'Misty'
    return result

def getWeatherIntentHandler(coinname):
    coinname = "".join(coinname.split())
    price = getWeatherInfo(coinname)
    #return f"The weather of {coinname} is {price}"
    return f"Currently, it is {price} in {coinname}"

@app.route("/", methods = ["POST"])
def main():
    
    req = request.get_json(silent=True, force=True)
    print(req)
    print('*'*100)
    intent_name = req["queryResult"]["intent"]["displayName"]

    if intent_name == "GetWeatherIntent":
        coinname = req["queryResult"]["parameters"]["locname"]
        print(coinname)
        print('*'*100)
        resp_text = getWeatherIntentHandler(coinname)
    else:
        resp_text = "Unable to find a matching intent. Try again."

    resp = {
        "fulfillmentText": resp_text
    }

    return Response(json.dumps(resp), status=200, content_type="application/json")

app.run(host='0.0.0.0', port=5000, debug=True)